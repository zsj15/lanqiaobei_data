/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "interrupt.h"
#include "lcd.h"
#include "string.h"
#include "i2c_hal.h"
#include "stdio.h"
#include "led.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */



/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
extern struct keys key[4];

int site = 1;

int Hour = 00;
int Minute = 00;
int Second = 00;


char Hour_flag;
char Minute_flag;
char Second_flag;

char set_time_Hour_flag;
char set_time_Minute_flag;
char set_time_Second_flag;


int jiemian_defalut_flag = 1;

char tim_start_flag;
char tim_stop_flag;
char tim_close_flag;

char start_to_stop_flag = 0;
extern char return_to_zero_flag;

char led_shansuo_flag;

char pwm_start_stop_flag;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */


void display_jiemian(void);
void Change_site(void);
void Set_time(void);  //���� B2 Ϊʱ��λ�ã�ʱ���֡��룩�л����ʹ洢��
void Change_time(void);  //���� B3 Ϊʱ���֡��루���� B2 ȷ����ǰλ�ã��������Ӽ�
void TIM_start_stop(void);
void check_return_to_zero(void);
void Set_pwm_output(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	LCD_Init();
	
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM16_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */

	LED_init();
	
	HAL_TIM_Base_Start_IT(&htim2);

	Hour = my_I2Cread(11);
	HAL_Delay(20);
	Minute =  my_I2Cread(12);
	HAL_Delay(20);
	Second =my_I2Cread(13);
	HAL_Delay(20);
	
	HAL_TIM_Base_Start_IT(&htim6);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  
	  display_jiemian();
	  Change_site();
	  Set_time();
	  Change_time();
	  TIM_start_stop();
	  check_return_to_zero();
	  Set_pwm_output();
	  

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV3;
  RCC_OscInitStruct.PLL.PLLN = 20;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */


void display_jiemian()
{
	
	
	//////////////////////////�ϵ�Ĭ�Ͻ���/////////////////////////////////////
	if(jiemian_defalut_flag == 1)
	{
	
	char text[30];
	LCD_SetTextColor(Black);	
	sprintf(text,"   NO  %d",site);
	LCD_DisplayStringLine(Line2, (uint8_t *)text);
	
	LCD_DisplayChar(Line5,212,(Hour/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,196,(Hour%10) + 0x30);		
	LCD_DisplayChar(Line5,180, ':');	
		
	LCD_DisplayChar(Line5,164,(Minute/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,148,(Minute%10) + 0x30);		
	LCD_DisplayChar(Line5,132, ':');		
	
	LCD_DisplayChar(Line5,116,(Second/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,100,(Second%10) + 0x30);		
	
	sprintf(text,"      Standby       ");
	LCD_DisplayStringLine(Line8, (uint8_t *)text);
	
	}
	
	//////////////////////////��ʱ�����н���/////////////////////////////////////
	if((tim_start_flag == 1)&&(return_to_zero_flag != 1))
	{
	
	char text[30];

	LCD_SetTextColor(Black);	
	sprintf(text,"   NO  %d",site);
	LCD_DisplayStringLine(Line2, (uint8_t *)text);

	LCD_DisplayChar(Line5,212,(Hour/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,196,(Hour%10) + 0x30);		
	LCD_DisplayChar(Line5,180, ':');	
		
	LCD_DisplayChar(Line5,164,(Minute/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,148,(Minute%10) + 0x30);		
	LCD_DisplayChar(Line5,132, ':');		
	
	LCD_DisplayChar(Line5,116,(Second/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,100,(Second%10) + 0x30);		
	
	sprintf(text,"      Running       ");
	LCD_DisplayStringLine(Line8, (uint8_t *)text);
		
	}
	
	//////////////////////////��ʱ��ֹͣ����/////////////////////////////////////
	if((tim_stop_flag == 1) &&(return_to_zero_flag != 1))
	{
	
	char text[30];

	LCD_SetTextColor(Black);	
	sprintf(text,"   NO  %d",site);
	LCD_DisplayStringLine(Line2, (uint8_t *)text);

	LCD_DisplayChar(Line5,212,(Hour/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,196,(Hour%10) + 0x30);		
	LCD_DisplayChar(Line5,180, ':');	
		
	LCD_DisplayChar(Line5,164,(Minute/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,148,(Minute%10) + 0x30);		
	LCD_DisplayChar(Line5,132, ':');		
	
	LCD_DisplayChar(Line5,116,(Second/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
	LCD_DisplayChar(Line5,100,(Second%10) + 0x30);		
	
	sprintf(text,"      Pause       ");
	LCD_DisplayStringLine(Line8, (uint8_t *)text);
		
	
	}
	
	//////////////////////////��ʱ���˳�����/////////////////////////////////////
	if((tim_close_flag == 1) &&(return_to_zero_flag != 1) )
	{
		jiemian_defalut_flag = 1;  //�ص�Ĭ�Ͻ���
		
		tim_close_flag = 0;
	}

	
	
}




void Change_site(void)      // B1   ���� B1 Ϊ�洢λ���л���
{
	
	if(key[0].key_flag == 1)
	{
		site += 1;
		
		key[0].key_flag = 0;
		
		if(site == 6)
		{
			site = 1;
		}	
	}	
	
}


void Set_time(void)  //���� B2 Ϊʱ��λ�ã�ʱ���֡��룩�л����ʹ洢�� 
{

	if(key[1].key_flag == 1)
	{		
			Hour_flag += 1;
			key[1].key_flag = 0;
			jiemian_defalut_flag = 0;	
	}

	if(Hour_flag == 4)
	{
		Hour_flag = 1;	
	}
	
	
		
		if(Hour_flag == 1)
		{
			char text[30];
			
			sprintf(text,"   NO  %d",site);
			LCD_DisplayStringLine(Line2, (uint8_t *)text);
		
			LCD_SetTextColor(Red);
			LCD_DisplayChar(Line5,212,(Hour/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,196,(Hour%10) + 0x30);		
			
			LCD_SetTextColor(Black);	
			
			LCD_DisplayChar(Line5,180, ':');	
			
		
			LCD_DisplayChar(Line5,164,(Minute/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,148,(Minute%10) + 0x30);		
			LCD_DisplayChar(Line5,132, ':');		
			
			LCD_DisplayChar(Line5,116,(Second/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,100,(Second%10) + 0x30);		
			
			sprintf(text,"      Standby       ");
			LCD_DisplayStringLine(Line8, (uint8_t *)text);
			
			set_time_Hour_flag = 1;
			set_time_Minute_flag = 0;
			set_time_Second_flag = 0;
			
		}
	
	
		if(Hour_flag == 2)
		{
			char text[30];
			
			sprintf(text,"   NO  %d",site);
			LCD_DisplayStringLine(Line2, (uint8_t *)text);
		
			
			LCD_DisplayChar(Line5,212,(Hour/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,196,(Hour%10) + 0x30);		
			LCD_DisplayChar(Line5,180, ':');	
			
			
			LCD_SetTextColor(Red);
			
			LCD_DisplayChar(Line5,164,(Minute/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,148,(Minute%10) + 0x30);	

			LCD_SetTextColor(Black);	
			
			LCD_DisplayChar(Line5,132, ':');		
			
			LCD_DisplayChar(Line5,116,(Second/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,100,(Second%10) + 0x30);		
			
			sprintf(text,"      Standby       ");
			LCD_DisplayStringLine(Line8, (uint8_t *)text);
			
			set_time_Hour_flag = 0;
			set_time_Minute_flag = 1;
			set_time_Second_flag = 0;
		}	
	
		if(Hour_flag == 3)
		{
			char text[30];
			
			sprintf(text,"   NO  %d",site);
			LCD_DisplayStringLine(Line2, (uint8_t *)text);
		
			
			LCD_DisplayChar(Line5,212,(Hour/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,196,(Hour%10) + 0x30);		
			LCD_DisplayChar(Line5,180, ':');	
					
			LCD_DisplayChar(Line5,164,(Minute/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,148,(Minute%10) + 0x30);	

			LCD_DisplayChar(Line5,132, ':');	
			
			LCD_SetTextColor(Red);
			
			LCD_DisplayChar(Line5,116,(Second/10) + 0x30);    //���ص��Ǵ��������� ,��Χ��1-320
			LCD_DisplayChar(Line5,100,(Second%10) + 0x30);		
			
			LCD_SetTextColor(Black);	
			
			sprintf(text,"      Standby       ");
			LCD_DisplayStringLine(Line8, (uint8_t *)text);
			
			set_time_Hour_flag = 0;
			set_time_Minute_flag = 0;
			set_time_Second_flag = 1;
		}			
		
		
////////////////////////////////// �洢ʱ�� /////////////////////////////////////////////////////
		if(key[1].key_long_flag == 1)
		{
			if(site == 1)    //�����1����洢��11 12 13 ��λ��
			{
				my_I2Cwrite(11,Hour);
				HAL_Delay(20);
				my_I2Cwrite(12,Minute);
				HAL_Delay(20);
				my_I2Cwrite(13,Second);
				HAL_Delay(20);
							
			}
			
			if(site == 2)    //�����2����洢��21 22 23 ��λ��
			{
				my_I2Cwrite(21,Hour);
				HAL_Delay(20);
				my_I2Cwrite(22,Minute);
				HAL_Delay(20);
				my_I2Cwrite(23,Second);
				HAL_Delay(20);			
				
			}
		
			if(site == 3)    //�����3����洢��31 32 33 ��λ��
			{
				my_I2Cwrite(31,Hour);
				HAL_Delay(20);
				my_I2Cwrite(32,Minute);
				HAL_Delay(20);
				my_I2Cwrite(33,Second);
				HAL_Delay(20);
							
			}
			
			if(site == 4)    //�����4����洢��41 42 43 ��λ��
			{
				my_I2Cwrite(41,Hour);
				HAL_Delay(20);
				my_I2Cwrite(42,Minute);
				HAL_Delay(20);
				my_I2Cwrite(43,Second);
				HAL_Delay(20);
							
			}
			
			if(site == 5)    //�����5����洢��51 52 53 ��λ��
			{
				my_I2Cwrite(51,Hour);
				HAL_Delay(20);
				my_I2Cwrite(52,Minute);
				HAL_Delay(20);
				my_I2Cwrite(53,Second);
				HAL_Delay(20);
				
			}
					
	
			jiemian_defalut_flag = 1;
			
			key[1].key_long_flag = 0;
			
			set_time_Hour_flag = 0;
			set_time_Minute_flag = 0;
			set_time_Second_flag = 0;
			
			
		}		
		
}



void Change_time(void)  //���� B3 Ϊʱ���֡��루���� B2 ȷ����ǰλ�ã��������Ӽ�
{

/////////////////////////////Hour����////////////////////////////////
	if(set_time_Hour_flag == 1)
	{
		if(key[2].key_flag  == 1)
		{
			
			Hour += 1;
			
			if(Hour == 25)
			{
				Hour = 0;
			}
			
			key[2].key_flag  = 0;
			
		}
			
		if(key[2].key_long_flag == 1)
		{
			Hour += 1;
			
			if(Hour == 25)
			{
				Hour = 0;
			}
			
			key[2].key_long_flag = 0;
		}
	}
		
/////////////////////////////Minute����////////////////////////////////
	if(set_time_Minute_flag == 1)
	{
		if(key[2].key_flag  == 1)
		{
			
			Minute += 1;
			
			if(Minute == 60)
			{
				Hour += 1;
				Minute = 0;
			}
			
			key[2].key_flag  = 0;
			
		}
			
		if(key[2].key_long_flag == 1)
		{
			Minute += 1;
			
			if(Minute == 60)
			{
				Hour += 1;
				Minute = 0;
			}
			
			key[2].key_long_flag = 0;
		}	
	}		
		
/////////////////////////////Second����////////////////////////////////
	if(set_time_Second_flag == 1)
	{
		if(key[2].key_flag  == 1)
		{
			
			Second += 1;
			
			if(Second == 60)
			{
				Minute += 1;
				Second = 0;
			}
			
			key[2].key_flag  = 0;
			
		}
			
		if(key[2].key_long_flag == 1)
		{
			Second += 1;
			
			if(Second == 60)
			{
				Minute += 1;
				Second = 0;
			}
			
			key[2].key_long_flag = 0;
			
		}				
	}	


}




void TIM_start_stop(void)
{
	//////////////////////��ʱ������/////////////////////////////
	if((key[3].key_flag == 1)&&(start_to_stop_flag == 0))  
	{
		jiemian_defalut_flag = 0;
		
		HAL_TIM_Base_Start_IT(&htim4);
		tim_stop_flag = 0;
		tim_start_flag = 1;
		
		start_to_stop_flag = !start_to_stop_flag;
		
		Hour_flag = 0;
		
		led_shansuo_flag = 1;
		pwm_start_stop_flag = 1;
		
		key[3].key_flag = 0;
	}
	
		
	//////////////////////��ʱ����ͣ/////////////////////////////
	if((key[3].key_flag == 1)&&(start_to_stop_flag == 1))
	{
		HAL_TIM_Base_Stop_IT(&htim4);
		tim_start_flag = 0;
		tim_stop_flag = 1;
		
		Hour_flag = 0;
		
		start_to_stop_flag = !start_to_stop_flag;
		
		led_shansuo_flag = 0;
		pwm_start_stop_flag = 0;
		
		key[3].key_flag = 0;
	}
		
	//////////////////////��ʱ���ر�/////////////////////////////
	if(key[3].key_long_flag == 1)
	{
		HAL_TIM_Base_Stop_IT(&htim4);
		
		tim_start_flag = 0;
		tim_stop_flag = 0;
		
		Hour_flag = 0;
		
		tim_close_flag = 1;
		led_shansuo_flag = 0;
		pwm_start_stop_flag = 0;
		
		key[3].key_long_flag = 0;
	}
	
}


void check_return_to_zero(void)
{
	if(return_to_zero_flag == 1)
	{
		HAL_TIM_Base_Stop_IT(&htim4);   //��ʱ������ʱ�������еı�־λ�����ֻ����Ĭ�ϵ���ʾ
		jiemian_defalut_flag = 1;
	
		Hour_flag = 0;
		tim_start_flag = 0;
		tim_stop_flag = 0;
		tim_close_flag = 0;
		led_shansuo_flag = 0;
		
		return_to_zero_flag = 0;
	}

}


void Set_pwm_output(void)
{
	if(pwm_start_stop_flag == 1)
	{
		HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);  //PWM���
	}
	if(pwm_start_stop_flag == 0)
	{
		HAL_TIM_PWM_Stop(&htim16, TIM_CHANNEL_1);  //PWM���
	}


}



int fputc(int ch,FILE *F)
{
	HAL_UART_Transmit(&huart1,(uint8_t *)&ch,1,0xFFF);
	return ch;
	
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
