/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd.h"
#include "interrupt.h"
#include "stdio.h"
#include "my_adc.h"
#include "led.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
extern struct keys key[4];

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

//#define DEBUG_INFO   //��ӡ������Ϣ��

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint32_t tickstart = 0;
float Vmax = 3.0f;
float Vmin = 1.0f;

float Vmax_set; //���õ�Vmax��Vmin��һ���м����
float Vmin_set;

int time_count;






/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void jiemian_display(void);
void time_count_set(void);


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_ADC2_Init();
  /* USER CODE BEGIN 2 */
	LCD_Init();

	HAL_TIM_Base_Start_IT(&htim4);

	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {		
	  jiemian_display();
	  time_count_set();
	  
	  LED_Set();
	  
	 // printf("my_adc.adc_Voltage_value:%.2f\r\n",Get_ADC_value(&hadc2));
	
	  
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV3;
  RCC_OscInitStruct.PLL.PLLN = 20;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */



int jiemian_default_flag = 0;
int jiemian_Para_flag = 0;
int LD2_check_error_flag = 0;

void jiemian_display(void)
{
	if(jiemian_default_flag == 0)
	{
		LCD_SetBackColor(Black);
		LCD_SetTextColor(White);
		
		char text[30];
		
		
		LCD_DisplayStringLine(Line0,(uint8_t *)"      Data          ");
		LCD_DisplayStringLine(Line1,(uint8_t *)"                    ");
		
		sprintf(text," V:%.2fV            ",Get_ADC_value(&hadc2));
		LCD_DisplayStringLine(Line2,(uint8_t *)text);
		

		sprintf(text," T:%ds               ",time_count);
		LCD_DisplayStringLine(Line3,(uint8_t *)text);
		LCD_DisplayStringLine(Line4,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line5,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line6,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line8,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
		
		key[1].key_flag = 0;  //��ֹĬ�Ͻ��� ����B2 B3�Բ����������ò���Ӱ��
		key[2].key_flag = 0;
	}


	if(jiemian_Para_flag == 1)
	{
		LCD_SetBackColor(Black);
		LCD_SetTextColor(White);
		
		char text[30];
		
		
		LCD_DisplayStringLine(Line0,(uint8_t *)"      Para          ");
		LCD_DisplayStringLine(Line1,(uint8_t *)"                    ");
		
		sprintf(text," Vmax:%.1fV            ",Vmax);
		LCD_DisplayStringLine(Line2,(uint8_t *)text);
		
		sprintf(text," Vmin:%.1fV            ",Vmin);
		LCD_DisplayStringLine(Line3,(uint8_t *)text);
		
		LCD_DisplayStringLine(Line4,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line5,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line6,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line8,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
	}
	
	//B1�л�����
	if(key[0].key_flag == 1)
	{
		jiemian_default_flag = !jiemian_default_flag;
		jiemian_Para_flag = !jiemian_Para_flag;
		
		
		if(jiemian_Para_flag == 1) //���½����������ʱ
		{
			Vmax_set = Vmax;
			Vmin_set = Vmin;
		}
		
		if(jiemian_default_flag == 0)  //�������£�����Ĭ�Ͻ���ʱ�������õ�ֵ�����ж�
		{
			if(Vmax < (Vmin + 1.0f))  //����ʱ���ָ�ԭֵ
			{
				LD2_check_error_flag = 1; //����ʱ��LED����
				Vmax = Vmax_set;
				Vmin = Vmin_set;		
			}
			else
			{
				LD2_check_error_flag = 0; //��ȷʱLD2Ϩ��
			}
		}
		
		key[0].key_flag = 0;
		
	}
	
	if(jiemian_Para_flag == 1)  //�����������ò���Ч
	{
		//����������棬��Vmax��Vmin ��ֵ����Ҫ���õ�Vmax_set��Vmin_set;�˳�ȥ��ʱ�����ж����õĲ����Ƿ����
			
		//B2 Vmax��
		if(key[1].key_flag == 1)
		{
			Vmax += 0.1f;
			if(Vmax >3.3f)
			{
				Vmax = 0.0f;
			}
			
			key[1].key_flag = 0;
			
		}
		
		//B3 Vmin��
		if(key[2].key_flag == 1)
		{
			Vmin += 0.1f;
			if(Vmin >3.3f)
			{
				Vmin = 0.0f;
			}
			
			key[2].key_flag = 0;
			
		}
	}
	

#ifdef DEBUG_INFO	
	printf("Vmax_set:%.1f\r\n",Vmax_set);
	printf("Vmin_set:%.1f\r\n",Vmin_set);
	printf("Vmax:%.1f\r\n",Vmax);
	printf("Vmin:%.1f\r\n",Vmin);
#endif

}



/*                    ��ʱ                         */

int adc_value_low_to_heigth_flag;
float adc_current_value;
int get_time_flag = 0;
int led_time_count_flag = 0;

void time_count_set(void)
{
	
#ifdef DEBUG_INFO	
	printf("HAL_GetTick:%d\r\n", HAL_GetTick());
#endif	
		adc_current_value = Get_ADC_value(&hadc2); //��ȡ��ǰֵ
		
		//����
		if((Get_ADC_value(&hadc2) - adc_current_value) >= 0)  //��Զ������������ 
		{
			adc_value_low_to_heigth_flag = 1;				
		}
		else  //�½�
		{
			adc_value_low_to_heigth_flag = 0;
		}
	

	if((Get_ADC_value(&hadc2) >= Vmin)&&(get_time_flag == 0))
	{
		if(tickstart == 0)  
		{
			//��ȡ��ʱ��ʼֵ
			tickstart = HAL_GetTick();   //���ֻ��Ҫֻ��һ��
			
			led_time_count_flag = 1; //��ʼ��ʱ
			//printf("tickstart:%d\r\n",tickstart);
		}
		
		
		//�����д���Vmax
		if((Get_ADC_value(&hadc2) >= Vmax)&&(adc_value_low_to_heigth_flag == 1))
		{
			time_count = (HAL_GetTick() - tickstart)/1000;   //msת s
			(HAL_GetTick()%tickstart == 0)?  time_count:time_count++;   //����ȡ��
			
			led_time_count_flag = 0; //led ��ʱ����
			get_time_flag = 1;				
		}			
	}
	

	if((get_time_flag == 1)&&(adc_value_low_to_heigth_flag == 0)&&((Get_ADC_value(&hadc2) < Vmin))) //��һ�μ�ʱ��ɺ󣬲��½�����VminС��ֵʱ���Ѳ�����0��׼�����¿�ʼ
	{
		get_time_flag = 0;
		time_count = 0;
		tickstart = 0;
	}
	
	//������ִ���Vmin Ȼ����С��Vminʱ�������������һ�δ�������������Vmin��ʱ����Ϊ��ʼʱ�䡣
	if((Get_ADC_value(&hadc2) < Vmin)&&(adc_value_low_to_heigth_flag == 0))
	{
		tickstart = 0;
	}
}













int fputc(int ch,FILE *F)
{
	 HAL_UART_Transmit(&huart1,(uint8_t *)&ch, 1, 0xFF);
	 return ch;
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
