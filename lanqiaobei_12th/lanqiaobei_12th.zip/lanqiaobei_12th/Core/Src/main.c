/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "interrupt.h"
#include "led.h"
#include "lcd.h"
#include "stdio.h"
#include "stdbool.h"
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
extern struct keys key[4];



/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//#define USER_FOR_DEBUG 



/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
bool jiemian_deflaut_flag = true;   //�ϵ����Ĭ�ϱ�־  Data����
bool jiemian_rate_flag = false;       //������ʱ�־λ

float Para_CNBR = 3.50f;
float Para_VNBR = 2.00f;

bool pwm_output_Hight_flag = false;  //�ϵ�Ĭ��pwm����͵�ƽ   pwm����ߵ�ƽ��־


extern char rxdate[30];   //���ڽ�������
extern uint8_t rxdat;
extern unsigned char point_count;

char car_type[5];   //ע������Ĵ�С���Ͻ�������/0��
char car_name[5];
char car_time[13];

///////////////////////////////////////////////////////
int car_count_in = 0; //����car��ͣ���� ����
int car_count_out = 0; //����car��ͣ���� ����

int car_out_parking_flag; //car �����־

int car_exist_flag = 0;  //����ʱ���������ڱ�־

int car_out_parking_num; //car ����ʱ�ı��

int rx_data_flag;

int time_for_parking;  //ͣ��ʱ��

int CNBR_count = 0;
int VNBR_count = 0;
//////////////////////////////////////////////////////



/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void jiemian_display(void);
void jiemian_key_Set(void);
void receive_car_information(void);
void check_car_information(void);
int time_get(char *old_time,char *new_time);
void LED_Set(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
	LCD_Init();

	HAL_TIM_Base_Start_IT(&htim4);

	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);

	HAL_UART_Receive_IT(&huart1,&rxdat, 1);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		jiemian_display();
		
		jiemian_key_Set();
	  
		receive_car_information();

		check_car_information();
	  
		LED_Set();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */



/////////////////////�������///////////////////////
void jiemian_display(void)
{

	if(jiemian_deflaut_flag == true)   //�ϵ���ʾĬ��Data���� ��λ��ʾ����
	{
		LCD_SetBackColor(Black);
		LCD_SetTextColor(White);
		
		char text[30];
		
		LCD_DisplayStringLine(Line0,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line1,(uint8_t *)"       Data         ");
		LCD_DisplayStringLine(Line2,(uint8_t *)"                    ");
		
		sprintf(text,"   CNBR:%d            ",CNBR_count);
		LCD_DisplayStringLine(Line3,(uint8_t *)text);
		
		LCD_DisplayStringLine(Line4,(uint8_t *)"                    ");
		
		sprintf(text,"   VNBR:%d            ",VNBR_count);
		LCD_DisplayStringLine(Line5,(uint8_t *)text);
		LCD_DisplayStringLine(Line6,(uint8_t *)"                    ");
		
		
		sprintf(text,"   IDLE:%d            ",(8-CNBR_count-VNBR_count));
		LCD_DisplayStringLine(Line7,(uint8_t *)text);
		LCD_DisplayStringLine(Line8,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
		
		key[1].key_flag = 0;  //��Ĭ�Ͻ������B2 B3��Ч����ֹ�Է������ò���Ӱ��
		key[2].key_flag = 0;
	
	}

	
	if(jiemian_rate_flag == true)   //������ʾ����
	{
		LCD_SetBackColor(Black);
		LCD_SetTextColor(White);
		
		char text[30];
		
		LCD_DisplayStringLine(Line0,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line1,(uint8_t *)"       Para         ");
		LCD_DisplayStringLine(Line2,(uint8_t *)"                    ");
		
		sprintf(text,"   CNBR:%.2f          ",Para_CNBR);
		LCD_DisplayStringLine(Line3,(uint8_t *)text);
		
		LCD_DisplayStringLine(Line4,(uint8_t *)"                    ");
		
		sprintf(text,"   VNBR:%.2f          ",Para_VNBR);
		LCD_DisplayStringLine(Line5,(uint8_t *)text);
		
		LCD_DisplayStringLine(Line6,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line8,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
		
	
	}




}


/////////////////////�������///////////////////////
//  B1�л�����      B2 ��      B3 ��       B4���� //
void jiemian_key_Set(void)
{
	//B1�л�����
	if(key[0].key_flag == 1)
	{
		jiemian_deflaut_flag = !jiemian_deflaut_flag;   //��־��ת
		jiemian_rate_flag = !jiemian_rate_flag;
		
		key[0].key_flag = 0;
		
	}


	//���ʼӼ�
	if(jiemian_rate_flag == true)   //ֻ���ڷ��ʽ����²����Ӽ�
	{		
		//B2 ��
		if(key[1].key_flag == 1)
		{
			Para_CNBR += 0.50f;
			Para_VNBR += 0.50f;
			
			key[1].key_flag = 0;
		}
		
		//B3 ��
		if(key[2].key_flag == 1)
		{
			Para_CNBR -= 0.50f;
			Para_VNBR -= 0.50f;
			
			if((Para_CNBR <= 0.00f)||(Para_VNBR <= 0.00f))
			{
				Para_CNBR = 0.00f;
				Para_VNBR = 0.00f;
			}
			
			key[2].key_flag = 0;
		}

	}
	
	// B4����
	if(key[3].key_flag == 1)   
	{
		
		pwm_output_Hight_flag = !pwm_output_Hight_flag;					//�����ź���͵�ƽ�ź�֮���л�
		
		if(pwm_output_Hight_flag == true)
		{
			__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_2,400);     //ARR 2000    CCR = 400     DUTY: 20%
		}
		
		if(pwm_output_Hight_flag == false)
		{
			__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_2,0);    //ARR 2000    CCR = 0     DUTY: 0%  ��������͵�ƽ
		}
		
	
		key[3].key_flag = 0;
	}

}




struct car_information_storages 
{
	char car_type_in[5];
	char car_type_out[5];
	
	char car_name_in[5];
	char car_name_out[5];
	
	char car_time_in[13];
	char car_time_out[13];
	
};



	
/////////////////////////���ڽ������ݲ������ݽ��з���////////////////////////////////
void receive_car_information(void)
{
	if(point_count != 0)  
	{
		if(point_count == 22) //�ڲ�����0��������յ�22���ַ�
		{
			
			sscanf(rxdate,"%4s:%4s:%12s",car_type,car_name,car_time);
				
			rx_data_flag = 1;
		
			printf("car_type:%4s\r\n",car_type);
			printf("car_name:%4s\r\n",car_name);
			printf("car_time:%12s\r\n",car_time);
			
			printf("rx_data_flag:%d\r\n",rx_data_flag);
			
			point_count = 0;
			memset(rxdate,0,30);
		
		}
		else
		{
			printf("ERROR");
			point_count = 0;
			memset(rxdate,0,30);
		}

	}
}


struct car_information_storages  car_information_storage[8] = {0,0,0,0,0,0};

void check_car_information(void)
{
	if(rx_data_flag == 1)           //��rx_data_count���и��º󣬻��߳��ֱ仯
	{

			if((car_name[0] != '\0'))  // ���car_name��car_information_storage[i].car_name_in�Ƿ�Ϊ��
			{			
				if((strcmp(car_information_storage[0].car_name_in,car_name) == 0) || (strcmp(car_information_storage[1].car_name_in,car_name) == 0)
					|| (strcmp(car_information_storage[2].car_name_in,car_name) == 0)|| (strcmp(car_information_storage[3].car_name_in,car_name) == 0)
					|| (strcmp(car_information_storage[4].car_name_in,car_name) == 0)|| (strcmp(car_information_storage[5].car_name_in,car_name) == 0)
					|| (strcmp(car_information_storage[6].car_name_in,car_name) == 0)|| (strcmp(car_information_storage[7].car_name_in,car_name) == 0))  //�Ƚϵ�ǰ�洢�ĳ�����Ϣ���Ƿ���ڵ�ǰ��������Ϣ
				{
					car_exist_flag = 1;   //ֻ�����һ������1
					
					rx_data_flag = 0;					
					printf("               include the car's information          \r\n");
						
				}
				else if((strcmp(car_information_storage[0].car_name_in,car_name) != 0) &&(strcmp(car_information_storage[1].car_name_in,car_name) != 0)
					&&(strcmp(car_information_storage[2].car_name_in,car_name) != 0)&&(strcmp(car_information_storage[3].car_name_in,car_name) != 0)
					&&(strcmp(car_information_storage[4].car_name_in,car_name) != 0)&&(strcmp(car_information_storage[5].car_name_in,car_name) != 0)
					&&(strcmp(car_information_storage[6].car_name_in,car_name) != 0)&&(strcmp(car_information_storage[7].car_name_in,car_name) != 0))
				{
					car_exist_flag = 2;   //������������0

					rx_data_flag = 0;					
					printf("           do not include the car's information                \r\n");
				}
				
			}		
		
		//rx_data_flag = 0;
	
	}

#ifdef USER_FOR_DEBUG	
	printf("car_exist_flag:%d\r\n",car_exist_flag);
	printf("rx_data_flag:%d\r\n",rx_data_flag);
#endif	
	
	
	if(car_exist_flag == 2)  //���������û��������
	{
		
		strcpy(car_information_storage[car_count_in].car_type_in,car_type);  //����car_type�е��ַ��� car_information_storage[car_count].car_type_in ��
		strcpy(car_information_storage[car_count_in].car_name_in,car_name);
		strcpy(car_information_storage[car_count_in].car_time_in,car_time);	
		
		if(strcmp(car_type, "CNBR") == 0)
		{
			CNBR_count += 1;
		}
		
		if(strcmp(car_type, "VNBR") == 0)
		{
			VNBR_count += 1;
		}
		
#ifdef USER_FOR_DEBUG		
		printf("1��car_information_storage[car_count_in].car_type_in:%s\r\n",car_information_storage[car_count_in].car_type_in);
		printf("2��car_information_storage[car_count_in].car_name_in:%s\r\n",car_information_storage[car_count_in].car_name_in);
		printf("3��car_information_storage[car_count_in].car_time_in:%s\r\n",car_information_storage[car_count_in].car_time_in);
#endif		
		
		car_count_in += 1;
		
		
		car_exist_flag = 0;
		
#ifdef USER_FOR_DEBUG		
		printf("car_count_in:%d\r\n",car_count_in);
#endif		
		
		if(car_count_in > 8)
		{
			printf("ERROR");
		}

	}
	
	
	if(car_exist_flag == 1)  //��������д���������
	{
		
		// car_count_out  ֱ��Ĭ��Ϊ0
		strcpy(car_information_storage[car_count_out].car_type_out,car_type);  //����car_type�е��ַ��� car_information_storage[car_count].car_type_in ��
		strcpy(car_information_storage[car_count_out].car_name_out,car_name);
		strcpy(car_information_storage[car_count_out].car_time_out,car_time);	
		
		if(strcmp(car_type, "CNBR") == 0)
		{
			CNBR_count -= 1;
		}
		
		if(strcmp(car_type, "VNBR") == 0)
		{
			VNBR_count -= 1;
		}
		
		
		
		
#ifdef USER_FOR_DEBUG		
		printf("4��car_information_storage[car_count_out].car_type_out:%s\r\n",car_information_storage[car_count_out].car_type_out);  //Ҫ��car_count_outǰ����ܴ�ӡ������֮��Ļ���car_count_out���1,��ӡ�����λ�ò���ͬһ�ڴ�
		printf("5��car_information_storage[car_count_out].car_name_out:%s\r\n",car_information_storage[car_count_out].car_name_out);
		printf("6��car_information_storage[car_count_out].car_time_out:%s\r\n",car_information_storage[car_count_out].car_time_out);
#endif
		car_out_parking_flag = 1;   //���������־	
		car_exist_flag = 0;
		
				
	}
	
	
	//��������,���������������־  car_out_parking_flag
	if(car_out_parking_flag == 1 )
	{
		for(int i = 0;i < 8;i++)
		{
			if(strcmp(car_information_storage[i].car_name_in,car_information_storage[car_count_out].car_name_out) ==0 )
			{
					//����ʱ����м���
					car_out_parking_num = i;
			}
			
		}
#ifdef USER_FOR_DEBUG
					printf("car_count_in:%d\r\n",car_count_in);
#endif				
					time_for_parking = time_get(car_information_storage[car_out_parking_num].car_time_in,car_information_storage[car_count_out].car_time_out);
				
				
			
					
					if(strcmp(car_information_storage[car_out_parking_num].car_type_out, "CNBR") == 0)
					{
						
						printf("time_for_test:%d\r\n",time_for_parking);
						
						printf("%4s:%4s:%2d:%.2f\r\n",car_information_storage[car_out_parking_num].car_type_out,
						car_information_storage[car_out_parking_num].car_name_out,time_for_parking,(time_for_parking * Para_CNBR));
						
						
					}
					
					if(strcmp(car_information_storage[car_out_parking_num].car_type_out, "VNBR") == 0)
					{
						
						printf("time_for_test:%d\r\n",time_for_parking);
						
						printf("%4s:%4s:%2d:%.2f\r\n",car_information_storage[car_out_parking_num].car_type_out,
						car_information_storage[car_out_parking_num].car_name_out,time_for_parking,(time_for_parking * Para_VNBR));
					}
		
					
					//������⣬����ǰ������ͣ�������е���0
					memset(car_information_storage[car_out_parking_num].car_name_in,0,5);
					memset(car_information_storage[car_out_parking_num].car_time_in,0,13);
					memset(car_information_storage[car_out_parking_num].car_type_in,0,5);

					//����ĳ�����ϢҲ���
					memset(car_information_storage[car_count_out].car_name_in,0,5);
					memset(car_information_storage[car_count_out].car_time_in,0,13);
					memset(car_information_storage[car_count_out].car_type_in,0,5);
					//����ʱ����м���
				
					car_out_parking_flag = 0; 
				
					
///////////////////////////////////////��������ṹ���е�����λ��Ӧ��ֻ�ܼӣ�����������е�λ�ò�û���ͷŵ�////////////////////////////////////////////////
///////////////////////////////////////               ������ˣ��п��ٸģ���������                       ////////////////////////////////////////////////					
					
//					memset(car_information_storage[i].car_type_in,0,5);
//					memset(car_information_storage[i].car_name_in,0,5);
//					memset(car_information_storage[i].car_time_in,0,5);
	
	}
	
	
	
	
	
	



}





////////////////////////����ʱ��////////////////////////////
struct TIMES_char 
{
	char year[3];
	char month[3];
	char day[3];
	char hour[3];
	char minute[3];
	char second[3];
	
};

struct TIMES_float 
{
	float year_count;
	float month_count;
	float day_count;
	float hour_count;
	float minute_count;
	float second_count;
	
};

//һ���365�죬�������Ƿ�Ϊ������;ֱ�Ӿ�һ���µ�30����м�����

struct TIMES_char time_old = {0,0,0,0,0,0};
struct TIMES_char time_new = {0,0,0,0,0,0};

struct TIMES_float  time_old_count ={0,0,0,0,0,0};
struct TIMES_float  time_new_count ={0,0,0,0,0,0};

float time;

extern float ceilf(float);

int time_get(char *old_time,char *new_time)
{
	sscanf(old_time,"%2s%2s%2s%2s%2s%2s",time_old.year,time_old.month,time_old.day,time_old.hour,time_old.minute,time_old.second);

	sscanf(new_time,"%2s%2s%2s%2s%2s%2s",time_new.year,time_new.month,time_new.day,time_new.hour,time_new.minute,time_new.second);
		
	
	time_old_count.year_count =  (time_old.year[0] - '0')*10 +(time_old.year[1] - '0');
	time_old_count.month_count =  (time_old.month[0] - '0')*10 +(time_old.month[1] - '0');
	time_old_count.day_count = (time_old.day[0] - '0')*10 +(time_old.day[1] - '0');
	time_old_count.hour_count = (time_old.hour[0] - '0')*10 +(time_old.hour[1] - '0');
	time_old_count.minute_count = (time_old.minute[0] - '0')*10 +(time_old.minute[1] - '0');
	time_old_count.second_count = (time_old.second[0] - '0')*10 +(time_old.second[1] - '0');
	
	time_new_count.year_count =  (time_new.year[0] - '0')*10 +(time_new.year[1] - '0');
	time_new_count.month_count =  (time_new.month[0] - '0')*10 +(time_new.month[1] - '0');
	time_new_count.day_count = (time_new.day[0] - '0')*10 +(time_new.day[1] - '0');
	time_new_count.hour_count = (time_new.hour[0] - '0')*10 +(time_new.hour[1] - '0');
	time_new_count.minute_count = (time_new.minute[0] - '0')*10 +(time_new.minute[1] - '0');
	time_new_count.second_count = (time_new.second[0] - '0')*10 +(time_new.second[1] - '0');
	
	
	
	if((time_new_count.second_count - time_old_count.second_count) < 0)  //�벻��
	{
		time_new_count.second_count += 60;
		time_new_count.minute_count -= 1;
	}
	
	if((time_new_count.minute_count - time_old_count.minute_count) < 0)  //���Ӳ���
	{
		time_new_count.minute_count += 60;
		time_new_count.hour_count -= 1;
	}
	
	if((time_new_count.day_count - time_old_count.day_count) < 0)  //��������
	{
		time_new_count.day_count += 30;
		time_new_count.month_count -= 1;
	}
	
	if((time_new_count.month_count - time_old_count.month_count) < 0)  //��������
	{
		time_new_count.month_count += 12;
		time_new_count.year_count -= 1;
	}
	
	if((time_new_count.year_count - time_old_count.year_count) < 0)
	{
		printf("ERROR");
	}
	

	time = ((time_new_count.year_count - time_old_count.year_count)*8760 +(time_new_count.month_count - time_old_count.month_count)*720 +
			(time_new_count.day_count - time_old_count.day_count)*24 + (time_new_count.hour_count - time_old_count.hour_count) +
			(time_new_count.minute_count - time_old_count.minute_count)/60 + (time_new_count.second_count - time_old_count.second_count)/3600);
	
	time = ceilf(time);  //��time��������ȡ������
	
	return time;
}














/////////�����ض���///////////
int fputc(int ch,FILE *F)
{
	HAL_UART_Transmit(&huart1,(uint8_t *)&ch,1,0xFF);
	return ch;
}






/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
