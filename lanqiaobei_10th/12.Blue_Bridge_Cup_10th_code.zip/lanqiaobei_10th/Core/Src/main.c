/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd.h"
#include "interrupt.h"
#include "stdio.h"
#include "my_adc.h"
#include "stdbool.h"
#include "led.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

extern struct keys key[4];

extern int led_count;
extern bool led_flag;



/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
int jiemian_deflaut_flag = 1; //����Ĭ�ϱ�־  
int jiemian_parameter_flag = 0;//���������־
int change_parameter_count = 0;

int LED_UP_count = 1;
int LED_LOW_count = 2;

int LED_UP_count_old;
int LED_LOW_count_old;


float Max_Volt = 2.4f;
float Min_Volt = 1.2f;

float ADC_Volt;

char *Status;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

void jeimian_dispaly(void);
void jeimian_change(void);
void LED_set(void);


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_ADC2_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */

	LCD_Init();

	HAL_TIM_Base_Start_IT(&htim4);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  
//	   printf("key[0].key_flag:%d\r\n",key[0].key_flag);

	  jeimian_dispaly();
	  jeimian_change();
	  LED_set();
	  
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */




void jeimian_dispaly(void)
{
	if(jiemian_deflaut_flag == 1)
	{
		char text[30];
		
		LCD_SetBackColor(Black);
		LCD_SetTextColor(White);
		
		LCD_DisplayStringLine(Line0,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line1,(uint8_t *)"        Main        ");
		LCD_DisplayStringLine(Line2,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line3,(uint8_t *)"                    ");
		
		ADC_Volt = Get_adc_value(&hadc2);
		sprintf(text,"     Volt:%.2fV     ",ADC_Volt);
		LCD_DisplayStringLine(Line4,(uint8_t *)text);
		
		LCD_DisplayStringLine(Line5,(uint8_t *)"                    ");
		
		sprintf(text,"     Status: %s  ",Status);
		LCD_DisplayStringLine(Line6,(uint8_t *)text);
		
		LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line8,(uint8_t *)"                    ");
		LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
		
		key[1].key_flag = 0;  //��ʾ���水B2��Ч
		key[2].key_flag = 0;  //��ʾ���水B3��Ч
		key[3].key_flag = 0;  //��ʾ���水B4��Ч
		
		
	}

	if(jiemian_parameter_flag == 1)
	{
		if(change_parameter_count == 0)  //����Ĭ�Ͻ���
		{
			char text[30];
			
			LCD_SetBackColor(Black);
			LCD_SetTextColor(White);
			
			LCD_DisplayStringLine(Line0,(uint8_t *)"                    ");
			LCD_DisplayStringLine(Line1,(uint8_t *)"       Setting      ");
			

			sprintf(text,"  Max Volt:%.1fV     ",Max_Volt);
			LCD_DisplayStringLine(Line2,(uint8_t *)text);
			
			LCD_DisplayStringLine(Line3,(uint8_t *)"                    ");
			
			sprintf(text,"  Min Volt:%.1fV     ",Min_Volt);
			LCD_DisplayStringLine(Line4,(uint8_t *)text);
			
			LCD_DisplayStringLine(Line5,(uint8_t *)"                    ");
			

			sprintf(text,"  Upper:LD%d         ",LED_UP_count);
			LCD_DisplayStringLine(Line6,(uint8_t *)text);
			LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");
			
			sprintf(text,"  Lower:LD%d         ",LED_LOW_count);
			LCD_DisplayStringLine(Line8,(uint8_t *)text);
			
			LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
		}
		
			if(change_parameter_count == 1)
			{				

				char text[30];
			
				LCD_SetBackColor(Black);
				LCD_SetTextColor(White);
				
				LCD_DisplayStringLine(Line0,(uint8_t *)"                    ");
				LCD_DisplayStringLine(Line1,(uint8_t *)"       Setting      ");
				
				LCD_SetBackColor(Yellow);	
				sprintf(text,"  Max Volt:%.1fV     ",Max_Volt);
				LCD_DisplayStringLine(Line2,(uint8_t *)text);
				LCD_SetBackColor(Black);
				
				LCD_DisplayStringLine(Line3,(uint8_t *)"                    ");
			
				sprintf(text,"  Min Volt:%.1fV     ",Min_Volt);
				LCD_DisplayStringLine(Line4,(uint8_t *)text);
				
				LCD_DisplayStringLine(Line5,(uint8_t *)"                    ");
				
				sprintf(text,"  Upper:LD%d         ",LED_UP_count);
				LCD_DisplayStringLine(Line6,(uint8_t *)text);
				LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");
				
				sprintf(text,"  Lower:LD%d         ",LED_LOW_count);
				LCD_DisplayStringLine(Line8,(uint8_t *)text);
				
				LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
				
				
				
			}
			if(change_parameter_count == 2)
			{
				char text[30];
			
				LCD_SetBackColor(Black);
				LCD_SetTextColor(White);
				
				LCD_DisplayStringLine(Line0,(uint8_t *)"                    ");
				LCD_DisplayStringLine(Line1,(uint8_t *)"       Setting      ");
				
				sprintf(text,"  Max Volt:%.1fV     ",Max_Volt);
				LCD_DisplayStringLine(Line2,(uint8_t *)text);
		
				LCD_DisplayStringLine(Line3,(uint8_t *)"                    ");
				
				LCD_SetBackColor(Yellow);

				sprintf(text,"  Min Volt:%.1fV     ",Min_Volt);
				LCD_DisplayStringLine(Line4,(uint8_t *)text);
				LCD_SetBackColor(Black);
				
				LCD_DisplayStringLine(Line5,(uint8_t *)"                    ");
				
				sprintf(text,"  Upper:LD%d         ",LED_UP_count);
				LCD_DisplayStringLine(Line6,(uint8_t *)text);
				LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");
			
				sprintf(text,"  Lower:LD%d         ",LED_LOW_count);
				LCD_DisplayStringLine(Line8,(uint8_t *)text);
				
				LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
				
				
			}
			if(change_parameter_count == 3)
			{
				char text[30];
			
				LCD_SetBackColor(Black);
				LCD_SetTextColor(White);
				
				LCD_DisplayStringLine(Line0,(uint8_t *)"                    ");
				LCD_DisplayStringLine(Line1,(uint8_t *)"       Setting      ");
				
				sprintf(text,"  Max Volt:%.1fV     ",Max_Volt);
				LCD_DisplayStringLine(Line2,(uint8_t *)text);
			
				LCD_DisplayStringLine(Line3,(uint8_t *)"                    ");
			
				sprintf(text,"  Min Volt:%.1fV     ",Min_Volt);
				LCD_DisplayStringLine(Line4,(uint8_t *)text);
				
				LCD_DisplayStringLine(Line5,(uint8_t *)"                    ");
				
				LCD_SetBackColor(Yellow);
				sprintf(text,"  Upper:LD%d         ",LED_UP_count);
				LCD_DisplayStringLine(Line6,(uint8_t *)text);
				LCD_SetBackColor(Black);
							
				LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");
				
				sprintf(text,"  Lower:LD%d         ",LED_LOW_count);
				LCD_DisplayStringLine(Line8,(uint8_t *)text);
				
				LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");

			}
			if(change_parameter_count == 4)
			{
				char text[30];
				
				LCD_SetBackColor(Black);
				LCD_SetTextColor(White);
				
				LCD_DisplayStringLine(Line0,(uint8_t *)"                    ");
				LCD_DisplayStringLine(Line1,(uint8_t *)"       Setting      ");
				
				sprintf(text,"  Max Volt:%.1fV     ",Max_Volt);
				LCD_DisplayStringLine(Line2,(uint8_t *)text);
				
				LCD_DisplayStringLine(Line3,(uint8_t *)"                    ");
				
				sprintf(text,"  Min Volt:%.1fV     ",Min_Volt);
				LCD_DisplayStringLine(Line4,(uint8_t *)text);
				
				LCD_DisplayStringLine(Line5,(uint8_t *)"                    ");
				
				sprintf(text,"  Upper:LD%d         ",LED_UP_count);
				LCD_DisplayStringLine(Line6,(uint8_t *)text);
				
				LCD_DisplayStringLine(Line7,(uint8_t *)"                    ");

				LCD_SetBackColor(Yellow);
				sprintf(text,"  Lower:LD%d         ",LED_LOW_count);
				LCD_DisplayStringLine(Line8,(uint8_t *)text);
				LCD_SetBackColor(Black);
				
				LCD_DisplayStringLine(Line9,(uint8_t *)"                    ");
				
			}
	
	}




}


void jeimian_change(void)
{
	//�����л�
	if(key[0].key_flag == 1)
	{
		jiemian_deflaut_flag = !jiemian_deflaut_flag;
		jiemian_parameter_flag = !jiemian_parameter_flag;
		
		key[0].key_flag = 0;
		change_parameter_count = 0;//�л�����ǰ��ѡ�������־��0
		
		
			
		if((jiemian_deflaut_flag == 0)&&(jiemian_parameter_flag ==1))  //����ʾ���浽��������
		{
			//ÿ�ν���ǰ����һ�γɹ���LED�Ʊ�Ž��д洢
			 LED_UP_count_old = LED_UP_count;
			 LED_LOW_count_old = LED_LOW_count;
		}
		
		//��ֹ�ϡ�����ָʾ������Ϊͬһ��ָʾ��
		if((jiemian_deflaut_flag == 1)&&(jiemian_parameter_flag ==0))
		{
			if((int)LED_UP_count == (int)LED_LOW_count)  //��������򷵻���һ�ε�����  �˳�������������ʱ
			{
				LED_UP_count = LED_UP_count_old;
				LED_LOW_count = LED_LOW_count_old;
			}
		}

	}
	
	//����������
	if(jiemian_parameter_flag == 1)
	{	
		if(key[1].key_flag == 1)
		{
			change_parameter_count += 1;
				
			if(change_parameter_count > 5)
			{
				change_parameter_count = 1;
			}
				
			key[1].key_flag = 0;
		}
	}

	//B3������Ϊ���ӡ�������
	if(key[2].key_flag == 1)
	{	
		if(change_parameter_count == 1) //ֻ�е�ѹ������Ч
		{
			Max_Volt += 0.3f;
		}
		
		if(change_parameter_count == 2)
		{
			Min_Volt += 0.3f;
		}
		
		if(change_parameter_count == 3)
		{
			LED_UP_count += 1;
		}
		
		if(change_parameter_count == 4)
		{
			LED_LOW_count += 1;
		}
		
	
		key[2].key_flag = 0;
		
	}
	
	//B4������Ϊ������������
	if(key[3].key_flag == 1)
	{	
		if(change_parameter_count == 1) //ֻ�е�ѹ������Ч
		{
			Max_Volt -= 0.3f;
		}
		
		if(change_parameter_count == 2)
		{
			Min_Volt -= 0.3f;
		}
		
		
		if(change_parameter_count == 3)
		{
			LED_UP_count -= 1;
		}
		
		if(change_parameter_count == 4)
		{
			LED_LOW_count -= 1;
		}
	
		key[3].key_flag = 0;
		
	}
	
	
	/*   ��������   */
	//��ѹ����
	if(Max_Volt > 3.3f)
	{
		Max_Volt = 3.3f;
	}
	if(Max_Volt < 0)
	{
		Max_Volt = 0;
	}
	
	if(Min_Volt > 3.3f)
	{
		Min_Volt = 3.3f;
	}
	if(Min_Volt < 0)
	{
		Min_Volt = 0;
	}
	
		
	//LED�Ʊ������
	if(LED_UP_count > 8)
	{
		LED_UP_count = 8;
	}
	if(LED_UP_count < 1)
	{
		LED_UP_count = 1;
	}
	
	if(LED_LOW_count > 8)
	{
		LED_LOW_count = 8;
	}
	if(LED_LOW_count < 1)
	{
		LED_LOW_count = 1;
	}
}




void LED_set(void)
{
	if(ADC_Volt > Max_Volt)
	{
		HAL_TIM_Base_Start_IT(&htim2);
		Status = "Upper";
		
		printf("1111:%d\r\n",led_count);
		//if(LED_UP_count)
		LED_Status_Upper_shansuo();
		
	}
	
	if(ADC_Volt < Min_Volt)
	{
		HAL_TIM_Base_Start_IT(&htim2);
		Status = "Lower";
		
		LED_Status_Lower_shansuo();
	}

	if((Min_Volt <= ADC_Volt) &&(ADC_Volt <= Max_Volt))
	{
		HAL_TIM_Base_Stop_IT(&htim2);
		led_count = 0;
		
		Status = "Normal";
		
		LED_Stop_shansuo();
	}

	
	
	
	





}













int fputc(int ch,FILE *F)
{
	HAL_UART_Transmit(&huart1,(uint8_t *)&ch,1,0xFF);
	return ch;
}







/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
